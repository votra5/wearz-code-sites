#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Installe Wearz Code sur cet ordinateur :
1. Installe les dependances Python necessaires (PyQt5, PyQtWebEngine)
2. Copie l'application dans le dossier utilisateur (~/WearzCode)
3. Cree un raccourci sur le Bureau pour lancer l'app en un clic

Lancement :
    python install.py
"""

import os
import sys
import stat
import shutil
import subprocess

APP_FOLDER_NAME = "WearzCode"
SOURCE_DIR = os.path.dirname(os.path.abspath(__file__))
INSTALL_DIR = os.path.join(os.path.expanduser("~"), APP_FOLDER_NAME)
DESKTOP_DIR = os.path.join(os.path.expanduser("~"), "Desktop")


def install_dependencies():
    print("Installation des dependances (PyQt5, PyQtWebEngine)...")
    subprocess.run(
        [sys.executable, "-m", "pip", "install", "PyQt5", "PyQtWebEngine"],
        check=False,
    )


def copy_app_files():
    print(f"Copie de l'application vers {INSTALL_DIR} ...")
    if os.path.exists(INSTALL_DIR):
        shutil.rmtree(INSTALL_DIR)
    shutil.copytree(
        SOURCE_DIR,
        INSTALL_DIR,
        ignore=shutil.ignore_patterns("install.py", "__pycache__"),
    )


def create_shortcut():
    os.makedirs(DESKTOP_DIR, exist_ok=True)
    app_path = os.path.join(INSTALL_DIR, "app.py")

    if os.name == "nt":
        shortcut_path = os.path.join(DESKTOP_DIR, "Wearz Code.bat")
        with open(shortcut_path, "w", encoding="utf-8") as f:
            f.write(
                "@echo off\r\n"
                f'cd /d "{INSTALL_DIR}"\r\n'
                f'start "" pythonw "{app_path}"\r\n'
            )
    elif sys.platform == "darwin":
        shortcut_path = os.path.join(DESKTOP_DIR, "Wearz Code.command")
        with open(shortcut_path, "w", encoding="utf-8") as f:
            f.write(f'#!/bin/bash\ncd "{INSTALL_DIR}"\npython3 "{app_path}"\n')
        st = os.stat(shortcut_path)
        os.chmod(shortcut_path, st.st_mode | stat.S_IEXEC)
    else:
        shortcut_path = os.path.join(DESKTOP_DIR, "wearz-code.desktop")
        icon_path = os.path.join(INSTALL_DIR, "assets", "wearz_code_logo.png")
        with open(shortcut_path, "w", encoding="utf-8") as f:
            f.write(
                "[Desktop Entry]\n"
                "Type=Application\n"
                "Name=Wearz Code\n"
                f'Exec=python3 "{app_path}"\n'
                f"Icon={icon_path}\n"
                "Terminal=false\n"
            )
        st = os.stat(shortcut_path)
        os.chmod(shortcut_path, st.st_mode | stat.S_IEXEC)

    print(f"Raccourci cree sur le Bureau : {shortcut_path}")


def main():
    install_dependencies()
    copy_app_files()
    create_shortcut()
    print(
        "\nInstallation terminee ! Double-clique sur le raccourci "
        "'Wearz Code' sur ton Bureau pour lancer l'application."
    )


if __name__ == "__main__":
    main()
