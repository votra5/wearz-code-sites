#!/bin/bash
cd "$(dirname "$0")"

if command -v python3 &> /dev/null; then
    python3 install.py
elif command -v python &> /dev/null; then
    python install.py
else
    echo "ERREUR : Python n'a pas ete trouve sur cet ordinateur."
    echo "Installe Python depuis https://www.python.org/downloads/"
fi

echo ""
read -p "Appuie sur Entree pour fermer..."
