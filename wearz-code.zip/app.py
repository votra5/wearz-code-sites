#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Mini-IDE HTML avec connexion.

Dependances a installer avant de lancer :
    pip install PyQt5 PyQtWebEngine

Lancement :
    python app.py

Fonctionnalites :
- Ecran de connexion / inscription reel (email + mot de passe, stockage
  local chiffre par hash SHA-256/PBKDF2 dans une base SQLite users.db)
- Editeur de code HTML avec coloration syntaxique simple
- Bouton "Executer" qui ouvre le code dans un onglet de previsualisation web
- Terminal integre (vrai cmd.exe sous Windows / bash sous Linux-Mac)
- Menu "Fichier" -> Ouvrir un fichier / Ouvrir un dossier, avec panneau
  "Recents" pour retrouver rapidement ce qui a ete ouvert
- Console de debogage qui affiche les erreurs Python de l'appli ET les
  erreurs/avertissements JavaScript de la page previsualisee
"""

import sys
import os
import re
import json
import hashlib
import sqlite3
import secrets
import traceback
from datetime import datetime, timedelta

try:
    from PyQt5.QtCore import Qt, QProcess, QUrl, QRegExp
    from PyQt5.QtGui import (
        QFont, QTextCursor, QColor, QSyntaxHighlighter, QTextCharFormat,
        QPixmap, QIcon
    )
    from PyQt5.QtWidgets import (
        QApplication, QWidget, QMainWindow, QVBoxLayout, QHBoxLayout,
        QLabel, QLineEdit, QPushButton, QMessageBox, QPlainTextEdit,
        QTabWidget, QDockWidget, QListWidget, QListWidgetItem, QToolBar,
        QAction, QMenu, QFileDialog, QFrame, QToolButton,
        QSizePolicy, QCheckBox, QGraphicsDropShadowEffect
    )
    from PyQt5.QtWebEngineWidgets import QWebEngineView, QWebEnginePage
except ImportError:
    print("Dependances manquantes. Installe-les avec :")
    print("    pip install PyQt5 PyQtWebEngine")
    sys.exit(1)


APP_DIR = os.path.dirname(os.path.abspath(__file__))
DB_PATH = os.path.join(APP_DIR, "users.db")
RECENT_PATH = os.path.join(APP_DIR, "recent.json")
TMP_PREVIEW = os.path.join(APP_DIR, "_preview_tmp.html")
APP_NAME = "Wearz Code"
LOGO_PATH_PNG = os.path.join(APP_DIR, "assets", "wearz_code_logo.png")
LOGO_PATH_ICO = os.path.join(APP_DIR, "assets", "wearz_code_logo.ico")
LOGO_PATH = LOGO_PATH_ICO if os.path.exists(LOGO_PATH_ICO) else LOGO_PATH_PNG

EMAIL_RE = re.compile(r"^[^@\s]+@[^@\s]+\.[a-zA-Z]{2,}$")
SESSION_PATH = os.path.join(APP_DIR, ".session")

# ----------------------------------------------------------------------
# Feuille de style globale (theme clair, coherent avec le logo)
# ----------------------------------------------------------------------
APP_STYLESHEET = """
QWidget {
    font-family: 'Segoe UI', 'Inter', sans-serif;
    font-size: 13px;
    color: #1c1c1e;
}

QMainWindow {
    background: #f3f3f1;
}

QToolBar {
    background: #ffffff;
    border: none;
    border-bottom: 1px solid #e2e2de;
    padding: 6px 10px;
    spacing: 6px;
}

QToolBar QToolButton {
    background: transparent;
    border: none;
    border-radius: 6px;
    padding: 6px 10px;
    font-weight: 600;
}
QToolBar QToolButton:hover {
    background: #eef2fb;
    color: #2d6cdf;
}
QToolBar QToolButton::menu-indicator { width: 0px; }

QToolBar QAction, QToolButton {
    color: #1c1c1e;
}

QMenu {
    background: #ffffff;
    border: 1px solid #e2e2de;
    border-radius: 8px;
    padding: 6px;
}
QMenu::item {
    padding: 7px 22px 7px 14px;
    border-radius: 5px;
}
QMenu::item:selected {
    background: #eef2fb;
    color: #2d6cdf;
}
QMenu::separator {
    height: 1px;
    background: #ececec;
    margin: 6px 4px;
}

QDockWidget {
    font-weight: 600;
    titlebar-close-icon: none;
}
QDockWidget::title {
    background: #f7f7f5;
    padding: 8px 10px;
    border-bottom: 1px solid #e2e2de;
    color: #4a4a46;
}

QTabWidget::pane {
    border: none;
    border-top: 1px solid #e2e2de;
    background: #ffffff;
}
QTabBar::tab {
    background: transparent;
    padding: 8px 18px;
    margin-right: 2px;
    border-top-left-radius: 8px;
    border-top-right-radius: 8px;
    color: #6b6b68;
    font-weight: 600;
}
QTabBar::tab:selected {
    background: #ffffff;
    color: #2d6cdf;
    border: 1px solid #e2e2de;
    border-bottom: 2px solid #2d6cdf;
}
QTabBar::tab:hover:!selected {
    color: #1c1c1e;
}

QListWidget {
    background: #ffffff;
    border: none;
    outline: none;
    padding: 6px;
}
QListWidget::item {
    padding: 8px 10px;
    border-radius: 6px;
    margin-bottom: 2px;
}
QListWidget::item:hover {
    background: #f3f3f1;
}
QListWidget::item:selected {
    background: #eef2fb;
    color: #2d6cdf;
}

QLineEdit {
    background: #ffffff;
    border: 1px solid #dcdcd8;
    border-radius: 6px;
    padding: 6px 8px;
    selection-background-color: #2d6cdf;
}
QLineEdit:focus {
    border: 1px solid #2d6cdf;
}

QScrollBar:vertical {
    background: transparent;
    width: 10px;
    margin: 0;
}
QScrollBar::handle:vertical {
    background: #d3d3ce;
    border-radius: 5px;
    min-height: 24px;
}
QScrollBar::handle:vertical:hover {
    background: #b7b7b1;
}
QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical {
    height: 0px;
}

QScrollBar:horizontal {
    background: transparent;
    height: 10px;
}
QScrollBar::handle:horizontal {
    background: #d3d3ce;
    border-radius: 5px;
    min-width: 24px;
}

QStatusBar {
    background: #ffffff;
    border-top: 1px solid #e2e2de;
}
"""


# ----------------------------------------------------------------------
# Base de donnees / authentification
# ----------------------------------------------------------------------
def init_db():
    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()
    cur.execute("""
        CREATE TABLE IF NOT EXISTS users (
            email TEXT PRIMARY KEY,
            salt TEXT NOT NULL,
            password_hash TEXT NOT NULL,
            created_at TEXT NOT NULL
        )
    """)
    cur.execute("""
        CREATE TABLE IF NOT EXISTS sessions (
            token_hash TEXT PRIMARY KEY,
            email TEXT NOT NULL,
            expires_at TEXT NOT NULL
        )
    """)
    conn.commit()
    conn.close()


def hash_password(password, salt):
    return hashlib.pbkdf2_hmac(
        "sha256", password.encode("utf-8"), salt.encode("utf-8"), 100_000
    ).hex()


def create_user(email, password):
    salt = os.urandom(16).hex()
    pw_hash = hash_password(password, salt)
    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()
    try:
        cur.execute(
            "INSERT INTO users (email, salt, password_hash, created_at) "
            "VALUES (?, ?, ?, ?)",
            (email, salt, pw_hash, datetime.now().isoformat()),
        )
        conn.commit()
        return True, "Compte cree avec succes. Tu peux te connecter."
    except sqlite3.IntegrityError:
        return False, "Un compte existe deja avec cet e-mail."
    finally:
        conn.close()


def verify_user(email, password):
    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()
    cur.execute(
        "SELECT salt, password_hash FROM users WHERE email = ?", (email,)
    )
    row = cur.fetchone()
    conn.close()
    if not row:
        return False, "Aucun compte trouve avec cet e-mail."
    salt, stored_hash = row
    if hash_password(password, salt) == stored_hash:
        return True, "Connexion reussie."
    return False, "Mot de passe incorrect."


# ----------------------------------------------------------------------
# Session persistante ("Se souvenir de moi")
# ----------------------------------------------------------------------
def create_session(email, days=30):
    token = secrets.token_hex(32)
    token_hash = hashlib.sha256(token.encode("utf-8")).hexdigest()
    expires_at = (datetime.now() + timedelta(days=days)).isoformat()

    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()
    cur.execute("DELETE FROM sessions WHERE email = ?", (email,))
    cur.execute(
        "INSERT INTO sessions (token_hash, email, expires_at) VALUES (?, ?, ?)",
        (token_hash, email, expires_at),
    )
    conn.commit()
    conn.close()

    with open(SESSION_PATH, "w", encoding="utf-8") as f:
        json.dump({"email": email, "token": token}, f)


def load_session():
    """Renvoie l'e-mail associe a la session locale si elle est valide, sinon None."""
    if not os.path.exists(SESSION_PATH):
        return None
    try:
        with open(SESSION_PATH, "r", encoding="utf-8") as f:
            data = json.load(f)
        email, token = data.get("email"), data.get("token")
        if not email or not token:
            return None
        token_hash = hashlib.sha256(token.encode("utf-8")).hexdigest()

        conn = sqlite3.connect(DB_PATH)
        cur = conn.cursor()
        cur.execute(
            "SELECT expires_at FROM sessions WHERE token_hash = ? AND email = ?",
            (token_hash, email),
        )
        row = cur.fetchone()
        conn.close()

        if not row or datetime.now() > datetime.fromisoformat(row[0]):
            clear_session()
            return None
        return email
    except Exception:
        return None


def clear_session(email=None):
    if os.path.exists(SESSION_PATH):
        try:
            os.remove(SESSION_PATH)
        except Exception:
            pass
    if email:
        conn = sqlite3.connect(DB_PATH)
        cur = conn.cursor()
        cur.execute("DELETE FROM sessions WHERE email = ?", (email,))
        conn.commit()
        conn.close()


# ----------------------------------------------------------------------
# Coloration syntaxique HTML simple
# ----------------------------------------------------------------------
class HtmlHighlighter(QSyntaxHighlighter):
    def __init__(self, document):
        super().__init__(document)
        self.rules = []

        tag_format = QTextCharFormat()
        tag_format.setForeground(QColor("#569CD6"))
        self.rules.append((QRegExp(r"</?[a-zA-Z0-9\-]+"), tag_format))

        attr_format = QTextCharFormat()
        attr_format.setForeground(QColor("#9CDCFE"))
        self.rules.append((QRegExp(r"\b[a-zA-Z\-]+(?=\=)"), attr_format))

        string_format = QTextCharFormat()
        string_format.setForeground(QColor("#CE9178"))
        self.rules.append((QRegExp(r"\"[^\"]*\""), string_format))
        self.rules.append((QRegExp(r"'[^']*'"), string_format))

        comment_format = QTextCharFormat()
        comment_format.setForeground(QColor("#6A9955"))
        self.rules.append((QRegExp(r"<!--[^>]*-->"), comment_format))

        bracket_format = QTextCharFormat()
        bracket_format.setForeground(QColor("#808080"))
        self.rules.append((QRegExp(r"[<>=/]"), bracket_format))

    def highlightBlock(self, text):
        for pattern, fmt in self.rules:
            index = pattern.indexIn(text)
            while index >= 0:
                length = pattern.matchedLength()
                self.setFormat(index, length, fmt)
                index = pattern.indexIn(text, index + length)


# ----------------------------------------------------------------------
# Console de debogage
# ----------------------------------------------------------------------
class DebugConsole(QPlainTextEdit):
    COLORS = {
        "ERROR": "#F14C4C",
        "WARNING": "#CCA700",
        "INFO": "#3794FF",
        "OK": "#4EC9B0",
    }

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setReadOnly(True)
        self.setStyleSheet(
            "background-color:#1e1e1e; color:#d4d4d4; "
            "font-family: Consolas, 'Courier New', monospace; font-size: 12px;"
        )

    def log(self, message, level="INFO"):
        color = self.COLORS.get(level, "#d4d4d4")
        timestamp = datetime.now().strftime("%H:%M:%S")
        safe_msg = (
            message.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
        )
        self.appendHtml(
            f'<span style="color:#808080">[{timestamp}]</span> '
            f'<span style="color:{color}; font-weight:bold">[{level}]</span> '
            f'<span style="color:{color}">{safe_msg}</span>'
        )
        self.moveCursor(QTextCursor.End)


class DebugWebPage(QWebEnginePage):
    """Capture les erreurs/avertissements JavaScript de la page previsualisee."""

    LEVELS = {0: "INFO", 1: "WARNING", 2: "ERROR"}

    def __init__(self, debug_console, parent=None):
        super().__init__(parent)
        self.debug_console = debug_console

    def javaScriptConsoleMessage(self, level, message, line, source):
        level_name = self.LEVELS.get(level, "INFO")
        self.debug_console.log(
            f"JS: {message} (ligne {line}, source: {os.path.basename(source) or 'inline'})",
            level_name,
        )


# ----------------------------------------------------------------------
# Terminal integre
# ----------------------------------------------------------------------
class TerminalWidget(QWidget):
    def __init__(self, debug_console=None, parent=None):
        super().__init__(parent)
        self.debug_console = debug_console

        layout = QVBoxLayout(self)
        layout.setContentsMargins(4, 4, 4, 4)

        self.output = QPlainTextEdit()
        self.output.setReadOnly(True)
        self.output.setStyleSheet(
            "background-color:#0c0c0c; color:#d4d4d4; "
            "font-family: Consolas, 'Courier New', monospace; font-size: 12px;"
        )

        self.input = QLineEdit()
        self.input.setPlaceholderText("Tape une commande puis Entree...")
        self.input.setStyleSheet(
            "background-color:#0c0c0c; color:#ffffff; padding:4px; "
            "font-family: Consolas, monospace;"
        )
        self.input.returnPressed.connect(self.send_command)

        layout.addWidget(self.output)
        layout.addWidget(self.input)

        self.process = QProcess(self)
        self.process.setWorkingDirectory(APP_DIR)
        self.process.setProcessChannelMode(QProcess.MergedChannels)
        self.process.readyReadStandardOutput.connect(self.read_output)
        self.process.errorOccurred.connect(self.on_error)

        shell = "cmd.exe" if os.name == "nt" else "/bin/bash"
        self.process.start(shell)
        self.output.appendPlainText(f"--- Terminal demarre ({shell}) ---")

    def send_command(self):
        cmd = self.input.text()
        if not cmd:
            return
        self.output.appendPlainText(f"> {cmd}")
        try:
            self.process.write((cmd + "\n").encode("utf-8"))
        except Exception as exc:
            if self.debug_console:
                self.debug_console.log(f"Erreur terminal: {exc}", "ERROR")
        self.input.clear()

    def read_output(self):
        data = self.process.readAllStandardOutput().data().decode(
            "utf-8", errors="replace"
        )
        self.output.moveCursor(QTextCursor.End)
        self.output.insertPlainText(data)
        self.output.moveCursor(QTextCursor.End)

    def on_error(self, error):
        if self.debug_console:
            self.debug_console.log(f"Erreur du processus terminal: {error}", "ERROR")

    def shutdown(self):
        if self.process.state() != QProcess.NotRunning:
            self.process.kill()
            self.process.waitForFinished(1000)


# ----------------------------------------------------------------------
# Ecran de connexion / inscription / verification par code
# ----------------------------------------------------------------------
class LoginWindow(QWidget):
    def __init__(self, on_success):
        super().__init__()
        self.on_success = on_success
        self.mode_login = True

        self.setWindowTitle(f"Connexion — {APP_NAME}")
        self.resize(420, 420)
        if os.path.exists(LOGO_PATH):
            self.setWindowIcon(QIcon(LOGO_PATH))

        self._build_login_page()
        self.setStyleSheet(
            "QWidget#loginRoot { background: qlineargradient(x1:0, y1:0, x2:1, y2:1, "
            "stop:0 #eef1f7, stop:1 #e6ebf5); }"
        )
        self.setObjectName("loginRoot")

    # ---- Page : connexion / inscription ----
    def _build_login_page(self):
        outer = QVBoxLayout(self)
        outer.setAlignment(Qt.AlignCenter)

        card = QFrame()
        card.setFixedWidth(360)
        card.setStyleSheet("QFrame { background:#ffffff; border-radius:14px; }")
        shadow = QGraphicsDropShadowEffect(card)
        shadow.setBlurRadius(40)
        shadow.setXOffset(0)
        shadow.setYOffset(12)
        shadow.setColor(QColor(20, 20, 20, 45))
        card.setGraphicsEffect(shadow)
        card_layout = QVBoxLayout(card)
        card_layout.setContentsMargins(34, 34, 34, 30)
        card_layout.setSpacing(13)

        self.logo_label = QLabel()
        self.logo_label.setAlignment(Qt.AlignCenter)
        if os.path.exists(LOGO_PATH_PNG):
            pixmap = QPixmap(LOGO_PATH_PNG).scaledToHeight(90, Qt.SmoothTransformation)
            self.logo_label.setPixmap(pixmap)

        self.title_label = QLabel("Connexion")
        self.title_label.setStyleSheet("font-size:20px; font-weight:bold;")
        self.title_label.setAlignment(Qt.AlignCenter)

        self.email_input = QLineEdit()
        self.email_input.setPlaceholderText("Adresse e-mail")
        self.email_input.setStyleSheet(
            "padding:8px; border:1px solid #ccc; border-radius:5px;"
        )

        self.password_input = QLineEdit()
        self.password_input.setPlaceholderText("Mot de passe")
        self.password_input.setEchoMode(QLineEdit.Password)
        self.password_input.setStyleSheet(
            "padding:8px; border:1px solid #ccc; border-radius:5px;"
        )
        self.password_input.returnPressed.connect(self.submit)

        self.remember_checkbox = QCheckBox("Se souvenir de moi")
        self.remember_checkbox.setStyleSheet("font-size:12px;")

        self.status_label = QLabel("")
        self.status_label.setWordWrap(True)
        self.status_label.setAlignment(Qt.AlignCenter)
        self.status_label.setStyleSheet("color:#c0392b; font-size:12px;")

        self.submit_button = QPushButton("Se connecter")
        self.submit_button.setStyleSheet(
            "QPushButton { background:#2d6cdf; color:white; padding:9px; "
            "border-radius:5px; font-weight:bold; }"
            "QPushButton:hover { background:#245ab8; }"
        )
        self.submit_button.clicked.connect(self.submit)

        self.toggle_button = QPushButton("Pas encore de compte ? Inscris-toi")
        self.toggle_button.setStyleSheet(
            "QPushButton { background:transparent; color:#2d6cdf; border:none; }"
        )
        self.toggle_button.clicked.connect(self.toggle_mode)

        card_layout.addWidget(self.logo_label)
        card_layout.addWidget(self.title_label)
        card_layout.addWidget(self.email_input)
        card_layout.addWidget(self.password_input)
        card_layout.addWidget(self.remember_checkbox)
        card_layout.addWidget(self.status_label)
        card_layout.addWidget(self.submit_button)
        card_layout.addWidget(self.toggle_button)

        outer.addWidget(card)
    def toggle_mode(self):
        self.mode_login = not self.mode_login
        if self.mode_login:
            self.title_label.setText("Connexion")
            self.submit_button.setText("Se connecter")
            self.toggle_button.setText("Pas encore de compte ? Inscris-toi")
        else:
            self.title_label.setText("Inscription")
            self.submit_button.setText("Creer mon compte")
            self.toggle_button.setText("Deja un compte ? Connecte-toi")
        self.status_label.setText("")

    def submit(self):
        email = self.email_input.text().strip()
        password = self.password_input.text()

        if not EMAIL_RE.match(email):
            self.status_label.setText("Adresse e-mail invalide.")
            return
        if len(password) < 6:
            self.status_label.setText(
                "Le mot de passe doit contenir au moins 6 caracteres."
            )
            return

        if self.mode_login:
            ok, msg = verify_user(email, password)
            if ok:
                if self.remember_checkbox.isChecked():
                    create_session(email)
                self.status_label.setText("")
                self.on_success(email)
            else:
                self.status_label.setText(msg)
        else:
            ok, msg = create_user(email, password)
            self.status_label.setStyleSheet(
                "color:#27ae60; font-size:12px;" if ok else "color:#c0392b; font-size:12px;"
            )
            self.status_label.setText(msg)
            if ok:
                self.toggle_mode()


# ----------------------------------------------------------------------
# Fenetre principale (IDE)
# ----------------------------------------------------------------------
class MainWindow(QMainWindow):
    def __init__(self, user_email, on_logout=None):
        super().__init__()
        self.user_email = user_email
        self.on_logout = on_logout
        self.current_file_path = None
        self.recent_items = self._load_recent()

        self.setWindowTitle(f"{APP_NAME} — connecte en tant que {user_email}")
        self.resize(1200, 800)
        if os.path.exists(LOGO_PATH):
            self.setWindowIcon(QIcon(LOGO_PATH))

        self._build_debug_console()
        self._build_central_area()
        self._build_terminal_dock()
        self._build_recent_dock()
        self._build_toolbar()

        sys.excepthook = self._global_exception_hook

        self.debug_console.log("Application prete.", "OK")

    # ---- Construction UI ----
    def _build_debug_console(self):
        self.debug_console = DebugConsole()

    def _build_central_area(self):
        self.tabs = QTabWidget()

        self.editor = QPlainTextEdit()
        self.editor.setFont(QFont("Consolas", 11))
        self.editor.setStyleSheet(
            "background-color:#1e1e1e; color:#d4d4d4; "
            "font-family: Consolas, 'Courier New', monospace;"
        )
        self.editor.setPlainText(
            "<!DOCTYPE html>\n<html>\n<head>\n"
            "  <meta charset=\"utf-8\">\n  <title>Ma page</title>\n</head>\n"
            "<body>\n  <h1>Bonjour !</h1>\n"
            "  <script>\n    console.log(\"Page chargee\");\n  </script>\n"
            "</body>\n</html>\n"
        )
        self.highlighter = HtmlHighlighter(self.editor.document())

        self.preview = QWebEngineView()
        self.debug_page = DebugWebPage(self.debug_console, self.preview)
        self.preview.setPage(self.debug_page)

        self.tabs.addTab(self.editor, "Editeur")
        self.tabs.addTab(self.preview, "Previsualisation")

        self.setCentralWidget(self.tabs)

    def _build_terminal_dock(self):
        self.terminal = TerminalWidget(debug_console=self.debug_console)

        bottom_tabs = QTabWidget()
        bottom_tabs.addTab(self.terminal, "Terminal")
        bottom_tabs.addTab(self.debug_console, "Console de debogage")

        dock = QDockWidget("Terminal / Debogage", self)
        dock.setWidget(bottom_tabs)
        dock.setAllowedAreas(Qt.BottomDockWidgetArea)
        self.addDockWidget(Qt.BottomDockWidgetArea, dock)
        self.bottom_dock = dock

    def _build_recent_dock(self):
        self.recent_list = QListWidget()
        self.recent_list.itemDoubleClicked.connect(self._open_recent_item)
        self._refresh_recent_list()

        dock = QDockWidget("Fichiers / dossiers recents", self)
        dock.setWidget(self.recent_list)
        dock.setAllowedAreas(Qt.LeftDockWidgetArea | Qt.RightDockWidgetArea)
        self.addDockWidget(Qt.LeftDockWidgetArea, dock)

    def _build_toolbar(self):
        toolbar = QToolBar("Barre d'outils")
        toolbar.setMovable(False)
        self.addToolBar(toolbar)

        if os.path.exists(LOGO_PATH_PNG):
            logo_label = QLabel()
            logo_pixmap = QPixmap(LOGO_PATH_PNG).scaledToHeight(
                26, Qt.SmoothTransformation
            )
            logo_label.setPixmap(logo_pixmap)
            logo_label.setContentsMargins(6, 0, 8, 0)
            toolbar.addWidget(logo_label)

            name_label = QLabel(f"<b>{APP_NAME}</b>")
            name_label.setStyleSheet("font-size:14px; color:#1c1c1e;")
            name_label.setContentsMargins(0, 0, 14, 0)
            toolbar.addWidget(name_label)
            toolbar.addSeparator()

        # Bouton Fichier avec menu (Ouvrir un fichier / Ouvrir un dossier)
        file_button = QToolButton()
        file_button.setText("📁 Fichier  ▾")
        file_button.setPopupMode(QToolButton.InstantPopup)
        file_menu = QMenu(file_button)

        open_file_action = QAction("📄  Ouvrir un fichier (HTML)", self)
        open_file_action.triggered.connect(self.open_file)
        open_folder_action = QAction("📂  Ouvrir un dossier", self)
        open_folder_action.triggered.connect(self.open_folder)
        save_action = QAction("💾  Enregistrer", self)
        save_action.triggered.connect(self.save_file)

        file_menu.addAction(open_file_action)
        file_menu.addAction(open_folder_action)
        file_menu.addSeparator()
        file_menu.addAction(save_action)
        file_button.setMenu(file_menu)
        toolbar.addWidget(file_button)

        toolbar.addSeparator()

        run_button = QToolButton()
        run_button.setText("▶  Executer")
        run_button.setStyleSheet(
            "QToolButton { background:#2d6cdf; color:white; padding:6px 14px; "
            "border-radius:6px; font-weight:600; }"
            "QToolButton:hover { background:#245ab8; }"
        )
        run_button.clicked.connect(self.run_code)
        toolbar.addWidget(run_button)

        toolbar.addSeparator()

        spacer = QWidget()
        spacer.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Preferred)
        toolbar.addWidget(spacer)

        user_label = QLabel(f"  👤  {self.user_email}  ")
        user_label.setStyleSheet("color:#6b6b68;")
        toolbar.addWidget(user_label)

        logout_button = QToolButton()
        logout_button.setText("Se deconnecter")
        logout_button.setStyleSheet(
            "QToolButton { color:#c0392b; padding:6px 10px; border-radius:6px; }"
            "QToolButton:hover { background:#fbeaea; }"
        )
        logout_button.clicked.connect(self.logout)
        toolbar.addWidget(logout_button)

    def logout(self):
        clear_session(self.user_email)
        self.debug_console.log("Deconnexion.", "INFO")
        if self.on_logout:
            self.on_logout()
        self.close()

    # ---- Actions ----
    def run_code(self):
        try:
            html_code = self.editor.toPlainText()
            target_path = self.current_file_path or TMP_PREVIEW
            with open(target_path, "w", encoding="utf-8") as f:
                f.write(html_code)
            self.preview.setUrl(QUrl.fromLocalFile(target_path))
            self.tabs.setCurrentWidget(self.preview)
            self.debug_console.log(
                f"Code execute et charge dans la previsualisation ({os.path.basename(target_path)}).",
                "OK",
            )
        except Exception:
            self.debug_console.log(traceback.format_exc(), "ERROR")

    def open_file(self):
        path, _ = QFileDialog.getOpenFileName(
            self, "Ouvrir un fichier HTML", APP_DIR, "Fichiers HTML (*.html *.htm)"
        )
        if not path:
            return
        try:
            with open(path, "r", encoding="utf-8", errors="replace") as f:
                content = f.read()
            self.editor.setPlainText(content)
            self.current_file_path = path
            self.tabs.setCurrentWidget(self.editor)
            self._add_recent(path, "file")
            self.debug_console.log(f"Fichier ouvert : {path}", "INFO")
        except Exception:
            self.debug_console.log(traceback.format_exc(), "ERROR")

    def open_folder(self):
        path = QFileDialog.getExistingDirectory(self, "Ouvrir un dossier", APP_DIR)
        if not path:
            return
        self._add_recent(path, "folder")
        self.debug_console.log(f"Dossier ouvert : {path}", "INFO")

    def save_file(self):
        if not self.current_file_path:
            path, _ = QFileDialog.getSaveFileName(
                self, "Enregistrer sous", APP_DIR, "Fichiers HTML (*.html)"
            )
            if not path:
                return
            self.current_file_path = path
        try:
            with open(self.current_file_path, "w", encoding="utf-8") as f:
                f.write(self.editor.toPlainText())
            self._add_recent(self.current_file_path, "file")
            self.debug_console.log(f"Fichier enregistre : {self.current_file_path}", "OK")
        except Exception:
            self.debug_console.log(traceback.format_exc(), "ERROR")

    # ---- Gestion des elements recents ----
    def _load_recent(self):
        if os.path.exists(RECENT_PATH):
            try:
                with open(RECENT_PATH, "r", encoding="utf-8") as f:
                    return json.load(f)
            except Exception:
                return []
        return []

    def _save_recent(self):
        try:
            with open(RECENT_PATH, "w", encoding="utf-8") as f:
                json.dump(self.recent_items, f, ensure_ascii=False, indent=2)
        except Exception:
            self.debug_console.log(traceback.format_exc(), "ERROR")

    def _add_recent(self, path, kind):
        self.recent_items = [i for i in self.recent_items if i["path"] != path]
        self.recent_items.insert(0, {"path": path, "type": kind})
        self.recent_items = self.recent_items[:20]
        self._save_recent()
        self._refresh_recent_list()

    def _refresh_recent_list(self):
        self.recent_list.clear()
        for item in self.recent_items:
            icon = "📄" if item["type"] == "file" else "📁"
            list_item = QListWidgetItem(f"{icon}  {item['path']}")
            list_item.setData(Qt.UserRole, item)
            self.recent_list.addItem(list_item)

    def _open_recent_item(self, list_item):
        data = list_item.data(Qt.UserRole)
        if not data:
            return
        path = data["path"]
        if data["type"] == "file":
            if not os.path.exists(path):
                self.debug_console.log(f"Fichier introuvable : {path}", "ERROR")
                return
            try:
                with open(path, "r", encoding="utf-8", errors="replace") as f:
                    self.editor.setPlainText(f.read())
                self.current_file_path = path
                self.tabs.setCurrentWidget(self.editor)
                self.debug_console.log(f"Fichier rouvert : {path}", "INFO")
            except Exception:
                self.debug_console.log(traceback.format_exc(), "ERROR")
        else:
            if os.path.exists(path):
                self.open_folder_path_in_dialog(path)

    def open_folder_path_in_dialog(self, start_path):
        path = QFileDialog.getExistingDirectory(self, "Dossier", start_path)
        if path:
            self._add_recent(path, "folder")

    # ---- Gestion globale des erreurs Python ----
    def _global_exception_hook(self, exctype, value, tb):
        error_text = "".join(traceback.format_exception(exctype, value, tb))
        try:
            self.debug_console.log(error_text, "ERROR")
        except Exception:
            pass
        print(error_text, file=sys.stderr)

    def closeEvent(self, event):
        self.terminal.shutdown()
        if os.path.exists(TMP_PREVIEW):
            try:
                os.remove(TMP_PREVIEW)
            except Exception:
                pass
        event.accept()


# ----------------------------------------------------------------------
# Point d'entree
# ----------------------------------------------------------------------
def main():
    init_db()

    # Sous Windows, force la barre des taches a utiliser l'icone de
    # l'application plutot que celle de python.exe
    if os.name == "nt":
        try:
            import ctypes
            ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID(
                "WearzCode.MiniIDE.1.0"
            )
        except Exception:
            pass

    app = QApplication(sys.argv)
    app.setApplicationName(APP_NAME)
    app.setStyleSheet(APP_STYLESHEET)
    app.setFont(QFont("Segoe UI", 10))
    if os.path.exists(LOGO_PATH):
        app.setWindowIcon(QIcon(LOGO_PATH))

    state = {}

    def launch_main_window(email):
        if state.get("login"):
            state["login"].close()
        main_win = MainWindow(email, on_logout=launch_login_window)
        state["main"] = main_win
        main_win.show()

    def launch_login_window():
        if state.get("main"):
            state["main"] = None
        login_win = LoginWindow(on_success=launch_main_window)
        state["login"] = login_win
        login_win.show()

    # Si une session "Se souvenir de moi" valide existe, on saute
    # directement l'ecran de connexion et le code de verification.
    remembered_email = load_session()
    if remembered_email:
        launch_main_window(remembered_email)
    else:
        launch_login_window()

    sys.exit(app.exec_())


if __name__ == "__main__":
    main()
