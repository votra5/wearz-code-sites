@echo off
title Installation de Wearz Code
cd /d "%~dp0"

where python >nul 2>nul
if %errorlevel%==0 (
    python install.py
    goto end
)

where py >nul 2>nul
if %errorlevel%==0 (
    py install.py
    goto end
)

echo.
echo ERREUR : Python n'a pas ete trouve sur cet ordinateur.
echo Installe Python depuis https://www.python.org/downloads/
echo IMPORTANT : coche "Add python.exe to PATH" pendant l'installation.
echo.

:end
echo.
pause
